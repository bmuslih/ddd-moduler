//! Rust Clean Architecture DDD Modular - Main Entry Point
//!
//! This application demonstrates a feature-based DDD + Clean Architecture
//! implementation in Rust using Axum, deadpool_postgres, kanal, and modular crates.

use std::sync::Arc;
use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt};

use identity_transport::{create_identity_router, IdentityState};
use identity_transport::email_worker::spawn_email_worker;
use identity_adapters::KanalEventBus;

/// Initialize tracing
fn init_tracing() {
    tracing_subscriber::registry()
        .with(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| "info,rust_clean_ddd_modular=debug".into()),
        )
        .with(tracing_subscriber::fmt::layer())
        .init();
}

#[derive(Debug, thiserror::Error)]
pub enum AppError {
    #[error("Database error: {0}")]
    Database(String),
    
    #[error("Configuration error: {0}")]
    Config(String),
    
    #[error("Pool error: {0}")]
    Pool(String),
}

impl serde::Serialize for AppError {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::ser::Serializer,
    {
        serializer.serialize_str(self.to_string().as_ref())
    }
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    // Initialize logging
    init_tracing();
    
    tracing::info!("Starting Rust Clean DDD Modular Application");
    
    // Load environment variables
    dotenv::dotenv().ok();
    
    // Database configuration
    let db_host = std::env::var("DB_HOST").unwrap_or_else(|_| "localhost".to_string());
    let db_port = std::env::var("DB_PORT").unwrap_or_else(|_| "5432".to_string());
    let db_user = std::env::var("DB_USER").unwrap_or_else(|_| "postgres".to_string());
    let db_password = std::env::var("DB_PASSWORD").unwrap_or_else(|_| "postgres".to_string());
    let db_name = std::env::var("DB_NAME").unwrap_or_else(|_| "ddd_demo".to_string());
    
    let db_url = format!("postgres://{}:{}@{}:{}", db_user, db_password, db_host, db_port);
    
    // Create deadpool PostgreSQL configuration
    let mut cfg = deadpool_postgres::Config::new();
    cfg.host = Some(db_host);
    cfg.port = Some(db_port.parse().unwrap_or(5432));
    cfg.user = Some(db_user);
    cfg.password = Some(db_password);
    cfg.dbname = Some(db_name);
    
    // Create pool
    let pool = cfg.create_pool(
        Some(deadpool_postgres::Runtime::Tokio1),
        tokio_postgres::NoTls,
    ).map_err(|e| AppError::Pool(e.to_string()))?;
    
    // Get a client for initialization
    let client = pool.get().await
        .map_err(|e| AppError::Pool(e.to_string()))?;
    
    // Initialize database schema
    initialize_database(&*client).await?;
    
    // Release client
    drop(client);
    
    // Create event bus using kanal
    let event_bus = Arc::new(KanalEventBus::new());
    
    // Create identity state (workflows + repositories)
    let state = IdentityState::new(
        pool.clone(),
        event_bus.clone(),
    );
    
    // Spawn email worker (event receiver)
    let email_receiver = event_bus.subscribe();
    spawn_email_worker(email_receiver).await;
    
    // Create Axum application
    let app = create_identity_router(state);
    
    // Start server
    let addr = std::env::var("SERVER_ADDR").unwrap_or_else(|_| "0.0.0.0:3000".to_string());
    tracing::info!("Server listening on {}", addr);
    
    let listener = tokio::net::TcpListener::bind(&addr).await?;
    axum::serve(listener, app).await?;
    
    Ok(())
}

/// Initialize database schema
async fn initialize_database(client: &tokio_postgres::Client) -> Result<(), tokio_postgres::Error> {
    // Create users table
    client.execute(
        "CREATE TABLE IF NOT EXISTS users (
            id UUID PRIMARY KEY,
            email VARCHAR(255) NOT NULL UNIQUE,
            password_hash VARCHAR(255) NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT NOW()
        )",
        &[],
    ).await?;
    
    // Create outbox events table
    client.execute(
        "CREATE TABLE IF NOT EXISTS outbox_events (
            id UUID PRIMARY KEY,
            event_type VARCHAR(100) NOT NULL,
            payload JSONB NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT NOW(),
            processed BOOLEAN NOT NULL DEFAULT FALSE
        )",
        &[],
    ).await?;
    
    tracing::info!("Database schema initialized");
    
    Ok(())
}
