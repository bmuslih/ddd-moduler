//! Common Error Types
//!
//! Shared error types used across all modules.
//!
//! Alternative naming options:
//! 1. error (current)
//! 2. errors
//! 3. exceptions
//! 4. failures

use std::fmt;

/// Base error enum for the application
///
/// Alternative naming options:
/// 1. AppError (current)
/// 2. Error
/// 3. DomainError
/// 4. CoreError
#[derive(Debug)]
pub enum AppError {
    /// Validation error
    Validation(String),
    /// Not found error
    NotFound(String),
    /// Duplicate entry error
    Duplicate(String),
    /// Authentication error
    Unauthorized(String),
    /// Database error
    Database(String),
    /// Serialization error
    Serialization(String),
    /// Configuration error
    Config(String),
    /// Internal error
    Internal(String),
}

impl fmt::Display for AppError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            AppError::Validation(msg) => write!(f, "Validation error: {}", msg),
            AppError::NotFound(msg) => write!(f, "Not found: {}", msg),
            AppError::Duplicate(msg) => write!(f, "Duplicate: {}", msg),
            AppError::Unauthorized(msg) => write!(f, "Unauthorized: {}", msg),
            AppError::Database(msg) => write!(f, "Database error: {}", msg),
            AppError::Serialization(msg) => write!(f, "Serialization error: {}", msg),
            AppError::Config(msg) => write!(f, "Configuration error: {}", msg),
            AppError::Internal(msg) => write!(f, "Internal error: {}", msg),
        }
    }
}

impl std::error::Error for AppError {}

impl serde::Serialize for AppError {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::ser::Serializer,
    {
        serializer.serialize_str(self.to_string().as_ref())
    }
}

/// Result type alias
pub type Result<T> = std::result::Result<T, AppError>;

/// Convert from tokio_postgres::Error
impl From<tokio_postgres::Error> for AppError {
    fn from(err: tokio_postgres::Error) -> Self {
        AppError::Database(err.to_string())
    }
}

/// Convert from serde_json::Error
impl From<serde_json::Error> for AppError {
    fn from(err: serde_json::Error) -> Self {
        AppError::Serialization(err.to_string())
    }
}
