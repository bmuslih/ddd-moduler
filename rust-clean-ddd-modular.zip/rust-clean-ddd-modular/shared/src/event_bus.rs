//! Generic Event Bus
//!
//! High-performance event bus using kanal channels.
//! This is shared across all modules for domain event publishing.
//!
//! Alternative naming options:
//! 1. event_bus (current)
//! 2. message_bus
//! 3. event_system
//! 4. pub_sub

use std::any::Any;
use std::sync::Arc;
use chrono::{DateTime, Utc};
use kanal::{Sender, Receiver, unbounded_async};

/// Domain Event trait
///
/// Alternative naming options:
/// 1. DomainEvent (current)
/// 2. Event
/// 3. DomainSignal
/// 4. BusinessEvent
pub trait DomainEvent: Send + Sync + std::fmt::Debug + 'static {
    /// Unique event type identifier
    fn event_type(&self) -> &str;
    
    /// Get event payload as Any (for downcasting)
    fn as_any(&self) -> &dyn Any;
    
    /// When the event occurred
    fn occurred_at(&self) -> DateTime<Utc>;
}

/// Event Subscriber
///
/// Alternative naming options:
/// 1. EventSubscriber (current)
/// 2. Subscriber
/// 3. Listener
/// 4. Consumer
#[derive(Clone)]
pub struct EventSubscriber {
    receiver: Arc<Receiver<Box<dyn DomainEvent>>>,
}

impl EventSubscriber {
    pub fn new(receiver: Receiver<Box<dyn DomainEvent>>) -> Self {
        Self {
            receiver: Arc::new(receiver),
        }
    }
    
    /// Receive next event (async)
    pub async fn recv(&self) -> Option<Box<dyn DomainEvent>> {
        self.receiver.recv().await.ok()
    }
    
    /// Try to receive without blocking
    pub fn try_recv(&self) -> Option<Box<dyn DomainEvent>> {
        self.receiver.try_recv().ok()
    }
}

/// Event Publisher
///
/// Alternative naming options:
/// 1. EventPublisher (current)
/// 2. Publisher
/// 3. EventSender
/// 4. Bus
#[derive(Clone)]
pub struct EventPublisher {
    sender: Sender<Box<dyn DomainEvent>>,
}

impl EventPublisher {
    pub fn new(sender: Sender<Box<dyn DomainEvent>>) -> Self {
        Self { sender }
    }
    
    /// Publish an event
    pub async fn publish(&self, event: Box<dyn DomainEvent>) -> Result<(), EventBusError> {
        self.sender.send(event).await
            .map_err(EventBusError::from)
    }
}

/// Event Bus Error
#[derive(Debug, thiserror::Error)]
pub enum EventBusError {
    #[error("Send error: {0}")]
    SendError(String),
    
    #[error("Channel closed")]
    Closed,
}

impl From<kanal::SendError<Box<dyn DomainEvent>>> for EventBusError {
    fn from(err: kanal::SendError<Box<dyn DomainEvent>>) -> Self {
        EventBusError::SendError(err.to_string())
    }
}

/// Event Bus - Creates publishers and subscribers
///
/// Alternative naming options:
/// 1. EventBus (current)
/// 2. EventSystem
/// 3. MessageBus
/// 4. PubSub
pub struct EventBus {
    sender: Sender<Box<dyn DomainEvent>>,
}

impl EventBus {
    /// Create new event bus
    pub fn new() -> Self {
        let (sender, _) = unbounded_async();
        Self { sender }
    }
    
    /// Create a publisher
    pub fn publisher(&self) -> EventPublisher {
        EventPublisher::new(self.sender.clone())
    }
    
    /// Create a subscriber
    pub fn subscriber(&self) -> EventSubscriber {
        let (_, receiver) = unbounded_async();
        EventSubscriber::new(receiver)
    }
}

impl Default for EventBus {
    fn default() -> Self {
        Self::new()
    }
}
