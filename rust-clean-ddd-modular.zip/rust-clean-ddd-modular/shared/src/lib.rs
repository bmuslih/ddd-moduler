//! Shared Kernel
//!
//! Common components shared across all modules.
//! This is the innermost layer with NO external dependencies.
//!
//! Contains:
//! - Error types
//! - Event bus (optional)
//! - Common traits
//!
//! Alternative naming options:
//! 1. shared (current)
//! 2. kernel
//! 3. common
//! 4. foundation

pub mod error;

#[cfg(feature = "event-bus")]
pub mod event_bus;
