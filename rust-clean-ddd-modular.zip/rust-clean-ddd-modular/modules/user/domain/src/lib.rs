//! User Domain Layer
//!
//! Core business logic for user management (authentication).
//! Contains: User entity, Value Objects, Domain Events
//!
//! This is a BOUNDED CONTEXT - separate from Subscription!

pub mod value_objects;
pub mod user;
pub mod events;

pub use user::{User, UserId};
pub use value_objects::{UserEmail, HashedPassword, PlainPassword};
pub use events::{UserCreatedEvent, UserVerifiedEvent};
