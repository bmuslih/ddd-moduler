//! User Value Objects
//!
//! Immutable types with validation.

use std::fmt;
use regex::Regex;
use std::sync::OnceLock;

static EMAIL_REGEX: OnceLock<Regex> = OnceLock::new();

fn get_email_regex() -> &'static Regex {
    EMAIL_REGEX.get_or_init(|| {
        Regex::new(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$").unwrap()
    })
}

/// User Email Value Object
#[derive(Debug, Clone, PartialEq, Eq, Hash, serde::Serialize, serde::Deserialize)]
pub struct UserEmail(String);

impl UserEmail {
    pub fn new(email: impl Into<String>) -> Result<Self, ValueObjectError> {
        let email = email.into();
        
        if email.is_empty() {
            return Err(ValueObjectError::InvalidEmail("Email cannot be empty".into()));
        }
        
        if email.len() > 255 {
            return Err(ValueObjectError::InvalidEmail("Email too long (max 255 chars)".into()));
        }
        
        if !get_email_regex().is_match(&email) {
            return Err(ValueObjectError::InvalidEmail(format!("Invalid email format: {}", email)));
        }
        
        Ok(Self(email))
    }
    
    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl fmt::Display for UserEmail {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.0)
    }
}

impl AsRef<str> for UserEmail {
    fn as_ref(&self) -> &str {
        &self.0
    }
}

/// Hashed Password
#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct HashedPassword(String);

impl HashedPassword {
    pub fn from_hash(hash: impl Into<String>) -> Self {
        Self(hash.into())
    }
    
    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl fmt::Display for HashedPassword {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "***HASHED***")
    }
}

impl AsRef<str> for HashedPassword {
    fn as_ref(&self) -> &str {
        &self.0
    }
}

/// Plain Password (for validation only)
#[derive(Debug, Clone)]
pub struct PlainPassword(String);

impl PlainPassword {
    pub fn new(password: impl Into<String>) -> Result<Self, ValueObjectError> {
        let password = password.into();
        
        if password.len() < 8 {
            return Err(ValueObjectError::InvalidPassword(
                "Password must be at least 8 characters".into()
            ));
        }
        
        if password.len() > 128 {
            return Err(ValueObjectError::InvalidPassword(
                "Password too long (max 128 characters)".into()
            ));
        }
        
        if !password.chars().any(|c| c.is_ascii_digit()) {
            return Err(ValueObjectError::InvalidPassword(
                "Password must contain at least one digit".into()
            ));
        }
        
        Ok(Self(password))
    }
    
    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl fmt::Display for PlainPassword {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "***PASSWORD***")
    }
}

/// Value Object Errors
#[derive(Debug, thiserror::Error)]
pub enum ValueObjectError {
    #[error("Invalid email: {0}")]
    InvalidEmail(String),
    
    #[error("Invalid password: {0}")]
    InvalidPassword(String),
}

impl serde::Serialize for ValueObjectError {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::ser::Serializer,
    {
        serializer.serialize_str(self.to_string().as_ref())
    }
}
