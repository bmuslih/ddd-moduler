//! User Entity (Aggregate Root)

use chrono::{DateTime, Utc};
use uuid::Uuid;

use super::value_objects::{UserEmail, HashedPassword, PlainPassword};
use super::events::UserCreatedEvent;

/// User ID type
pub type UserId = Uuid;

/// User Status
#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum UserStatus {
    Pending,
    Active,
    Suspended,
}

/// User Entity
#[derive(Debug, Clone)]
pub struct User {
    pub id: UserId,
    pub email: UserEmail,
    pub password_hash: HashedPassword,
    pub status: UserStatus,
    pub verified: bool,
    pub created_at: DateTime<Utc>,
    pub events: Vec<Box<dyn crate::events::DomainEvent>>,
}

impl User {
    /// Create a new user (registration)
    pub fn register(email: UserEmail, password: PlainPassword) -> Result<Self, UserError> {
        let hash = bcrypt::hash(password.as_str(), 10)
            .map_err(|e| UserError::PasswordHashing(e.to_string()))?;
        
        let password_hash = HashedPassword::from_hash(hash);
        
        let user = Self {
            id: Uuid::new_v4(),
            email,
            password_hash,
            status: UserStatus::Pending,
            verified: false,
            created_at: Utc::now(),
            events: Vec::new(),
        };
        
        // Raise domain event
        let event = UserCreatedEvent::new(
            user.id.clone(),
            user.email.clone(),
            user.created_at,
        );
        
        tracing::info!("Domain Event: UserCreated(id={})", user.id);
        
        let mut user = user;
        user.events.push(Box::new(event));
        
        Ok(user)
    }
    
    /// Reconstruct from DB (no events)
    pub fn from_persistence(
        id: UserId,
        email: UserEmail,
        password_hash: HashedPassword,
        status: UserStatus,
        verified: bool,
        created_at: DateTime<Utc>,
    ) -> Self {
        Self {
            id,
            email,
            password_hash,
            status,
            verified,
            created_at,
            events: Vec::new(),
        }
    }
    
    /// Pull and clear events
    pub fn pull_events(&mut self) -> Vec<Box<dyn crate::events::DomainEvent>> {
        std::mem::take(&mut self.events)
    }
    
    /// Verify user (email verification)
    pub fn verify(&mut self) {
        self.verified = true;
        self.status = UserStatus::Active;
        
        let event = crate::events::UserVerifiedEvent::new(
            self.id.clone(),
            self.email.clone(),
            Utc::now(),
        );
        
        self.events.push(Box::new(event));
    }
    
    /// Verify password
    pub fn verify_password(&self, password: &PlainPassword) -> bool {
        bcrypt::verify(password.as_str(), self.password_hash.as_str())
            .unwrap_or(false)
    }
}

/// User Errors
#[derive(Debug, thiserror::Error)]
pub enum UserError {
    #[error("Invalid email: {0}")]
    InvalidEmail(#[from] super::value_objects::ValueObjectError),
    
    #[error("Password hashing error: {0}")]
    PasswordHashing(String),
    
    #[error("User not found")]
    NotFound,
    
    #[error("Duplicate email")]
    DuplicateEmail,
}

impl serde::Serialize for UserError {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::ser::Serializer,
    {
        serializer.serialize_str(self.to_string().as_ref())
    }
}
