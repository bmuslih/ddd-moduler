//! User Domain Events

use std::any::Any;
use chrono::{DateTime, Utc};
use uuid::Uuid;

/// Domain Event trait
pub trait DomainEvent: Send + Sync + std::fmt::Debug + 'static {
    fn event_type(&self) -> &str;
    fn as_any(&self) -> &dyn Any;
    fn occurred_at(&self) -> DateTime<Utc>;
}

/// User Created Event
#[derive(Debug, Clone)]
pub struct UserCreatedEvent {
    user_id: Uuid,
    email: super::value_objects::UserEmail,
    occurred_at: DateTime<Utc>,
}

impl UserCreatedEvent {
    pub fn new(user_id: Uuid, email: super::value_objects::UserEmail, occurred_at: DateTime<Utc>) -> Self {
        Self {
            user_id,
            email,
            occurred_at,
        }
    }
    
    pub fn user_id(&self) -> &Uuid {
        &self.user_id
    }
    
    pub fn email(&self) -> &super::value_objects::UserEmail {
        &self.email
    }
}

impl DomainEvent for UserCreatedEvent {
    fn event_type(&self) -> &str {
        "user.created"
    }
    
    fn as_any(&self) -> &dyn Any {
        self
    }
    
    fn occurred_at(&self) -> DateTime<Utc> {
        self.occurred_at
    }
}

/// User Verified Event
#[derive(Debug, Clone)]
pub struct UserVerifiedEvent {
    user_id: Uuid,
    email: super::value_objects::UserEmail,
    occurred_at: DateTime<Utc>,
}

impl UserVerifiedEvent {
    pub fn new(user_id: Uuid, email: super::value_objects::UserEmail, occurred_at: DateTime<Utc>) -> Self {
        Self {
            user_id,
            email,
            occurred_at,
        }
    }
    
    pub fn user_id(&self) -> &Uuid {
        &self.user_id
    }
}

impl DomainEvent for UserVerifiedEvent {
    fn event_type(&self) -> &str {
        "user.verified"
    }
    
    fn as_any(&self) -> &dyn Any {
        self
    }
    
    fn occurred_at(&self) -> DateTime<Utc> {
        self.occurred_at
    }
}
