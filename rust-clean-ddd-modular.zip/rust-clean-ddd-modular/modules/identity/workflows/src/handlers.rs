//! Workflow Handlers
//!
//! Contains the application logic that orchestrates the
//! execution of commands.
//!
//! Handlers:
//! 1. RegisterUserHandler - Handles user registration
//!
//! Alternative naming options:
//! 1. handlers (current)
//! 2. use_cases
//! 3. interactors
//! 4. services

use std::sync::Arc;
use deadpool::managed::Pool;
use deadpool_postgres::Object;
use async_trait::async_trait;

use super::commands::{RegisterUserCommand, CommandError};
use super::ports::{UserRepository, OutboxRepository, UserRepositoryError, OutboxError};
use identity_domain::{User, UserEmail, PlainPassword};

#[cfg(feature = "event-bus")]
use kanal::Sender;
#[cfg(feature = "event-bus")]
use identity_domain::events::DomainEvent;

/// Register User Workflow (Use Case)
///
/// This workflow orchestrates the user registration process:
/// 1. Get connection from pool
/// 2. Start transaction
/// 3. Check if email exists
/// 4. Create user entity (raises domain event)
/// 5. Save user to repository (passing transaction)
/// 6. Save event to outbox (passing same transaction)
/// 7. Commit transaction
/// 8. Dispatch event via event bus (after commit)
/// 
/// Alternative naming options:
/// 1. RegisterUserWorkflow (current)
/// 2. RegisterUserUseCase
/// 3. CreateUserHandler
/// 4. SignUpWorkflow
pub struct RegisterUserWorkflow {
    pool: Pool<deadpool_postgres::Manager>,
    user_repo: Arc<dyn UserRepository>,
    outbox_repo: Arc<dyn OutboxRepository>,
    #[cfg(feature = "event-bus")]
    event_sender: Sender<Box<dyn DomainEvent>>,
}

impl RegisterUserWorkflow {
    pub fn new(
        pool: Pool<deadpool_postgres::Manager>,
        user_repo: Arc<dyn UserRepository>,
        outbox_repo: Arc<dyn OutboxRepository>,
        #[cfg(feature = "event-bus")]
        event_sender: Sender<Box<dyn DomainEvent>>,
    ) -> Self {
        Self {
            pool,
            user_repo,
            outbox_repo,
            #[cfg(feature = "event-bus")]
            event_sender,
        }
    }
    
    /// Execute the register user workflow
    pub async fn execute(&self, command: RegisterUserCommand) -> Result<User, WorkflowError> {
        tracing::info!("Executing RegisterUserWorkflow for email: {}", command.email);
        
        // 1. Get connection from pool
        let mut client = self.pool.get().await
            .map_err(|e| WorkflowError::PoolError(e.to_string()))?;
        
        // 2. Start transaction
        let tx = client.transaction().await
            .map_err(|e| WorkflowError::TransactionError(e.to_string()))?;
        
        // 3. Check if email already exists
        if self.user_repo.exists_by_email(&tx, &command.email).await? {
            return Err(WorkflowError::DuplicateEmail(command.email));
        }
        
        // 4. Create user entity (raises domain event)
        let email = UserEmail::new(&command.email)
            .map_err(|e| WorkflowError::InvalidInput(e.to_string()))?;
        
        let password = PlainPassword::new(&command.password)
            .map_err(|e| WorkflowError::InvalidInput(e.to_string()))?;
        
        let mut user = User::new(email, password)
            .map_err(|e| WorkflowError::DomainError(e.to_string()))?;
        
        // 5. Save user (passing transaction - stateless repo)
        self.user_repo.save(&tx, &user)
            .await
            .map_err(|e| WorkflowError::RepositoryError(e))?;
        
        // 6. Save events to outbox (passing same transaction - guarantees atomicity!)
        for event in user.events.iter() {
            self.outbox_repo.save_event(&tx, event.as_ref())
                .await
                .map_err(|e| WorkflowError::RepositoryError(e))?;
        }
        
        // 7. Commit transaction
        tx.commit().await
            .map_err(|e| WorkflowError::TransactionError(e.to_string()))?;
        
        tracing::info!("Transaction committed for user: {}", user.id);
        
        // 8. Pull events and dispatch via event bus
        let events = user.pull_events();
        
        #[cfg(feature = "event-bus")]
        {
            for event in events {
                self.event_sender.send(event)
                    .await
                    .map_err(|e| WorkflowError::EventBusError(e.to_string()))?;
            }
        }
        
        Ok(user)
    }
}

/// Workflow Errors
///
/// Alternative naming options:
/// 1. WorkflowError (current)
/// 2. HandlerError
/// 3. UseCaseError
/// 4. ServiceError
#[derive(Debug, thiserror::Error)]
pub enum WorkflowError {
    #[error("Invalid input: {0}")]
    InvalidInput(String),
    
    #[error("Domain error: {0}")]
    DomainError(String),
    
    #[error("Repository error: {0}")]
    RepositoryError(#[from] UserRepositoryError),
    
    #[error("Outbox error: {0}")]
    OutboxError(#[from] OutboxError),
    
    #[error("Duplicate email: {0}")]
    DuplicateEmail(String),
    
    #[error("Pool error: {0}")]
    PoolError(String),
    
    #[error("Transaction error: {0}")]
    TransactionError(String),
    
    #[error("Event bus error: {0}")]
    EventBusError(String),
}

impl serde::Serialize for WorkflowError {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::ser::Serializer,
    {
        serializer.serialize_str(self.to_string().as_ref())
    }
}
