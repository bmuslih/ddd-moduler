//! Workflow Commands
//!
//! Commands represent intent to change state.
//!
//! Commands:
//! 1. RegisterUserCommand - Data needed to register a new user
//!
//! Alternative naming options:
//! 1. commands (current)
//! 2. requests
//! 3. input
//! 4. dtos

use serde::{Deserialize, Serialize};
use identity_domain::UserEmail;

/// Register User Command
///
/// Alternative naming options:
/// 1. RegisterUserCommand (current)
/// 2. CreateUserCommand
/// 3. SignUpCommand
/// 4. RegisterAccountCommand
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RegisterUserCommand {
    pub email: String,
    pub password: String,
}

impl RegisterUserCommand {
    pub fn new(email: impl Into<String>, password: impl Into<String>) -> Result<Self, CommandError> {
        let email = email.into();
        let password = password.into();
        
        if email.is_empty() {
            return Err(CommandError::Validation("Email is required".into()));
        }
        
        if password.is_empty() {
            return Err(CommandError::Validation("Password is required".into()));
        }
        
        // Validate email format
        UserEmail::new(&email)
            .map_err(|e| CommandError::Validation(e.to_string()))?;
        
        // Validate password
        identity_domain::PlainPassword::new(&password)
            .map_err(|e| CommandError::Validation(e.to_string()))?;
        
        Ok(Self { email, password })
    }
}

/// Command Errors
///
/// Alternative naming options:
/// 1. CommandError (current)
/// 2. HandlerError
/// 3. UseCaseError
/// 4. ApplicationError
#[derive(Debug, thiserror::Error)]
pub enum CommandError {
    #[error("Validation error: {0}")]
    Validation(String),
    
    #[error("Execution error: {0}")]
    Execution(String),
}

impl serde::Serialize for CommandError {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::ser::Serializer,
    {
        serializer.serialize_str(self.to_string().as_ref())
    }
}
