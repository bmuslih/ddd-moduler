//! Ports (Repository Traits)
//!
//! Interfaces that define how the workflows interact with
//! the outside world (database, event bus, etc.).
//!
//! This module re-exports from identity_shared and adds
//! additional ports specific to workflows.

pub use identity_shared::ports::{UserRepository, UserRepositoryError};

use async_trait::async_trait;
use tokio_postgres::GenericClient;
use uuid::Uuid;

/// Outbox Repository Port
///
/// Alternative naming options:
/// 1. OutboxRepository (current)
/// 2. EventStore
/// 3. EventOutbox
/// 4. MessageStore
#[async_trait]
pub trait OutboxRepository: Send + Sync {
    /// Save an event to the outbox (stateless)
    async fn save_event<C: GenericClient + Send + Sync>(
        &self,
        client: &C,
        event: &dyn identity_domain::events::DomainEvent,
    ) -> Result<(), OutboxError>;
    
    /// Get unprocessed events
    async fn get_unprocessed_events<C: GenericClient + Send + Sync>(
        &self,
        client: &C,
    ) -> Result<Vec<OutboxEvent>, OutboxError>;
    
    /// Mark events as processed
    async fn mark_processed<C: GenericClient + Send + Sync>(
        &self,
        client: &C,
        event_ids: &[Uuid],
    ) -> Result<(), OutboxError>;
}

/// Outbox Event structure
#[derive(Debug, Clone)]
pub struct OutboxEvent {
    pub id: Uuid,
    pub event_type: String,
    pub payload: String,
    pub created_at: chrono::DateTime<chrono::Utc>,
    pub processed: bool,
}

/// Outbox Repository Errors
#[derive(Debug, thiserror::Error)]
pub enum OutboxError {
    #[error("Database error: {0}")]
    Database(String),
    
    #[error("Serialization error: {0}")]
    Serialization(String),
}

impl From<tokio_postgres::Error> for OutboxError {
    fn from(err: tokio_postgres::Error) -> Self {
        OutboxError::Database(err.to_string())
    }
}

impl From<serde_json::Error> for OutboxError {
    fn from(err: serde_json::Error) -> Self {
        OutboxError::Serialization(err.to_string())
    }
}

impl serde::Serialize for OutboxError {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::ser::Serializer,
    {
        serializer.serialize_str(self.to_string().as_ref())
    }
}
