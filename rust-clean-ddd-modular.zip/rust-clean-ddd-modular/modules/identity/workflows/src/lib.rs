//! Identity Workflows Layer (Application Layer)
//!
//! Orchestrates the flow of data between domain and infrastructure.
//! Contains: Commands, Handlers, Ports (Repository Traits)
//!
//! Layer alternative names:
//! 1. workflows (current) ✅
//! 2. use_cases
//! 3. services
//! 4. application

pub mod commands;
pub mod handlers;
pub mod login;

pub use handlers::RegisterUserWorkflow;
pub use login::LoginWorkflow;
