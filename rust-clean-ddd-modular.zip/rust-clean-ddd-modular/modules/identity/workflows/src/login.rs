//! Login Workflow
//!
//! Handles user authentication/login.
//! Uses shared UserRepository port.
//!
//! Alternative naming options:
//! 1. login (current)
//! 2. authenticate
//! 3. sign_in
//! 4. auth

use std::sync::Arc;
use deadpool::managed::Pool;
use async_trait::async_trait;

use identity_shared::ports::{UserRepository, UserRepositoryError};
use identity_domain::{User, UserEmail, PlainPassword, value_objects::ValueObjectError};
use identity_shared::events::UserLoggedInEvent;

/// Login Command
pub struct LoginCommand {
    pub email: String,
    pub password: String,
    pub ip_address: Option<String>,
}

impl LoginCommand {
    pub fn new(email: impl Into<String>, password: impl Into<String>, ip_address: Option<String>) -> Result<Self, LoginError> {
        let email = email.into();
        let password = password.into();
        
        if email.is_empty() {
            return Err(LoginError::Validation("Email is required".into()));
        }
        
        if password.is_empty() {
            return Err(LoginError::Validation("Password is required".into()));
        }
        
        // Validate email format
        UserEmail::new(&email)
            .map_err(|e| LoginError::InvalidInput(e.to_string()))?;
        
        Ok(Self {
            email,
            password,
            ip_address,
        })
    }
}

/// Login Workflow
pub struct LoginWorkflow {
    pool: Pool<deadpool_postgres::Manager>,
    user_repo: Arc<dyn UserRepository>,
}

impl LoginWorkflow {
    pub fn new(
        pool: Pool<deadpool_postgres::Manager>,
        user_repo: Arc<dyn UserRepository>,
    ) -> Self {
        Self {
            pool,
            user_repo,
        }
    }
    
    pub async fn execute(&self, command: LoginCommand) -> Result<User, LoginError> {
        tracing::info!("Executing LoginWorkflow for email: {}", command.email);
        
        // Get connection from pool
        let client = self.pool.get().await
            .map_err(|e| LoginError::PoolError(e.to_string()))?;
        
        // Find user by email
        let user = self.user_repo.find_by_email(&*client, &command.email)
            .await
            .map_err(LoginError::RepositoryError)?
            .ok_or_else(|| LoginError::InvalidCredentials("Invalid email or password".into()))?;
        
        // Verify password
        let password = PlainPassword::new(&command.password)
            .map_err(|e| LoginError::InvalidInput(e.to_string()))?;
        
        if !user.verify_password(&password) {
            tracing::warn!("Invalid password attempt for email: {}", command.email);
            return Err(LoginError::InvalidCredentials("Invalid email or password".into()));
        }
        
        tracing::info!("User logged in successfully: {}", user.id);
        
        // Raise domain event
        let event = UserLoggedInEvent::new(
            user.id.clone(),
            user.email.clone(),
            command.ip_address,
        );
        
        // Note: In production, you'd save this event to outbox too
        // For simplicity, we just log it here
        
        Ok(user)
    }
}

/// Login Errors
#[derive(Debug, thiserror::Error)]
pub enum LoginError {
    #[error("Validation error: {0}")]
    Validation(String),
    
    #[error("Invalid input: {0}")]
    InvalidInput(String),
    
    #[error("Invalid credentials")]
    InvalidCredentials(String),
    
    #[error("Repository error: {0}")]
    RepositoryError(#[from] UserRepositoryError),
    
    #[error("Pool error: {0}")]
    PoolError(String),
}

impl serde::Serialize for LoginError {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::ser::Serializer,
    {
        serializer.serialize_str(self.to_string().as_ref())
    }
}
