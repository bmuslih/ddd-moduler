//! Identity Domain Layer
//!
//! Pure business logic with no external dependencies.
//! Contains: Entities, Value Objects, Domain Events
//!
//! Layer alternative names:
//! 1. domain (current)
//! 2. core
//! 3. model
//! 4. business_logic

pub mod value_objects;
pub mod user;
pub mod events;

pub use user::{User, UserId};
pub use value_objects::{UserEmail, HashedPassword, PlainPassword};
pub use events::UserCreatedEvent;
