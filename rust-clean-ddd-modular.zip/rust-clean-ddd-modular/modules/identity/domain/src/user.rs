//! User Entity (Aggregate Root)
//!
//! The User aggregate root encapsulates all user-related data and behavior.
//!
//! Alternative naming options:
//! 1. User (current)
//! 2. Account
//! 3. UserAccount
//! 4. Principal

use chrono::{DateTime, Utc};
use uuid::Uuid;

use super::value_objects::{UserEmail, HashedPassword, PlainPassword};
use super::events::UserCreatedEvent;

/// Domain Event trait - exported for workflows
#[cfg(feature = "event-bus")]
pub use crate::events::DomainEvent;

/// User ID type
pub type UserId = Uuid;

/// User Entity
///
/// Alternative naming options:
/// 1. User (current)
/// 2. UserAccount
/// 3. Account
/// 4. UserAggregate
#[derive(Debug, Clone)]
pub struct User {
    pub id: UserId,
    pub email: UserEmail,
    pub password_hash: HashedPassword,
    pub created_at: DateTime<Utc>,
    pub events: Vec<Box<dyn crate::events::DomainEvent>>,
}

impl User {
    /// Create a new user (factory method)
    /// Returns (User, Vec<DomainEvent>)
    pub fn new(email: UserEmail, password: PlainPassword) -> Result<Self, UserError> {
        let hash = bcrypt::hash(password.as_str(), 10)
            .map_err(|e| UserError::PasswordHashing(e.to_string()))?;
        
        let password_hash = HashedPassword::from_hash(hash);
        
        let user = Self {
            id: Uuid::new_v4(),
            email,
            password_hash,
            created_at: Utc::now(),
            events: Vec::new(),
        };
        
        // Raise domain event
        let event = UserCreatedEvent::new(
            user.id.clone(),
            user.email.clone(),
            user.created_at,
        );
        
        tracing::info!("Domain Event Raised: UserCreated(id={})", user.id);
        
        let mut user = user;
        user.events.push(Box::new(event));
        
        Ok(user)
    }
    
    /// Reconstruct from persistence (no events)
    pub fn from_persistence(
        id: UserId,
        email: UserEmail,
        password_hash: HashedPassword,
        created_at: DateTime<Utc>,
    ) -> Self {
        Self {
            id,
            email,
            password_hash,
            created_at,
            events: Vec::new(),
        }
    }
    
    /// Pull and clear events
    pub fn pull_events(&mut self) -> Vec<Box<dyn crate::events::DomainEvent>> {
        std::mem::take(&mut self.events)
    }
    
    /// Verify password
    pub fn verify_password(&self, password: &PlainPassword) -> bool {
        bcrypt::verify(password.as_str(), self.password_hash.as_str())
            .unwrap_or(false)
    }
}

/// User Errors
#[derive(Debug, thiserror::Error)]
pub enum UserError {
    #[error("Invalid email: {0}")]
    InvalidEmail(#[from] super::value_objects::ValueObjectError),
    
    #[error("Password hashing error: {0}")]
    PasswordHashing(String),
    
    #[error("User not found")]
    NotFound,
    
    #[error("Duplicate email")]
    DuplicateEmail,
}

impl serde::Serialize for UserError {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::ser::Serializer,
    {
        serializer.serialize_str(self.to_string().as_ref())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_create_user() {
        let email = UserEmail::new("test@example.com").unwrap();
        let password = PlainPassword::new("password123").unwrap();
        
        let user = User::new(email.clone(), password).unwrap();
        
        assert_eq!(user.email, email);
        assert!(!user.events.is_empty());
    }
}
