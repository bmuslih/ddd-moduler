//! Domain Events for Identity Module
//!
//! Significant occurrences within the domain that other parts
//! may be interested in.
//!
//! Events:
//! 1. UserCreatedEvent - Raised when a new user registers
//!
//! Alternative naming options:
//! 1. events (current)
//! 2. domain_events
//! 3. notifications
//! 4. signals

use std::any::Any;
use chrono::{DateTime, Utc};
use uuid::Uuid;

/// Domain Event trait
///
/// Alternative naming options:
/// 1. DomainEvent (current)
/// 2. Event
/// 3. DomainSignal
/// 4. BusinessEvent
pub trait DomainEvent: Send + Sync + std::fmt::Debug + 'static {
    fn event_type(&self) -> &str;
    fn as_any(&self) -> &dyn Any;
    fn occurred_at(&self) -> DateTime<Utc>;
}

/// User Created Event
///
/// Alternative naming options:
/// 1. UserCreatedEvent (current)
/// 2. UserRegisteredEvent
/// 3. AccountCreatedEvent
/// 4. NewUserEvent
#[derive(Debug, Clone)]
pub struct UserCreatedEvent {
    user_id: Uuid,
    email: super::value_objects::UserEmail,
    occurred_at: DateTime<Utc>,
}

impl UserCreatedEvent {
    pub fn new(user_id: Uuid, email: super::value_objects::UserEmail, occurred_at: DateTime<Utc>) -> Self {
        Self {
            user_id,
            email,
            occurred_at,
        }
    }
    
    pub fn user_id(&self) -> &Uuid {
        &self.user_id
    }
    
    pub fn email(&self) -> &super::value_objects::UserEmail {
        &self.email
    }
}

impl DomainEvent for UserCreatedEvent {
    fn event_type(&self) -> &str {
        "user.created"
    }
    
    fn as_any(&self) -> &dyn Any {
        self
    }
    
    fn occurred_at(&self) -> DateTime<Utc> {
        self.occurred_at
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_user_created_event() {
        let user_id = Uuid::new_v4();
        let email = super::UserEmail::new("test@example.com").unwrap();
        let occurred_at = Utc::now();
        
        let event = UserCreatedEvent::new(user_id, email.clone(), occurred_at);
        
        assert_eq!(event.event_type(), "user.created");
        assert_eq!(event.user_id(), &user_id);
    }
}
