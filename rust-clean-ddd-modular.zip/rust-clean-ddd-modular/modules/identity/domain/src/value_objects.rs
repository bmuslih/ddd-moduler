//! Value Objects for Identity Module
//!
//! Immutable types distinguished by their attribute values.
//! No identity, fully validated on creation.
//!
//! Value Objects:
//! 1. UserEmail - Validates email format
//! 2. HashedPassword - Wraps hashed password
//!
//! Alternative naming options:
//! 1. value_objects (current)
//! 2. attributes
//! 3. primitives
//! 4. types

use std::fmt;
use regex::Regex;
use std::sync::OnceLock;

/// Email validation regex
static EMAIL_REGEX: OnceLock<Regex> = OnceLock::new();

fn get_email_regex() -> &'static Regex {
    EMAIL_REGEX.get_or_init(|| {
        Regex::new(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$").unwrap()
    })
}

/// User Email Value Object
///
/// Alternative naming options:
/// 1. UserEmail (current)
/// 2. EmailAddress
/// 3. Email
/// 4. MailAddress
#[derive(Debug, Clone, PartialEq, Eq, Hash, serde::Serialize, serde::Deserialize)]
pub struct UserEmail(String);

impl UserEmail {
    pub fn new(email: impl Into<String>) -> Result<Self, ValueObjectError> {
        let email = email.into();
        
        if email.is_empty() {
            return Err(ValueObjectError::InvalidEmail("Email cannot be empty".into()));
        }
        
        if email.len() > 255 {
            return Err(ValueObjectError::InvalidEmail("Email too long (max 255 chars)".into()));
        }
        
        if !get_email_regex().is_match(&email) {
            return Err(ValueObjectError::InvalidEmail(format!("Invalid email format: {}", email)));
        }
        
        Ok(Self(email))
    }
    
    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl fmt::Display for UserEmail {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.0)
    }
}

impl AsRef<str> for UserEmail {
    fn as_ref(&self) -> &str {
        &self.0
    }
}

/// Hashed Password Value Object
///
/// Alternative naming options:
/// 1. HashedPassword (current)
/// 2. PasswordHash
/// 3. SecurePassword
/// 4. PasswordDigest
#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct HashedPassword(String);

impl HashedPassword {
    pub fn from_hash(hash: impl Into<String>) -> Self {
        Self(hash.into())
    }
    
    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl fmt::Display for HashedPassword {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "***HASHED***")
    }
}

impl AsRef<str> for HashedPassword {
    fn as_ref(&self) -> &str {
        &self.0
    }
}

/// Plain Password (for input validation only)
///
/// Alternative naming options:
/// 1. PlainPassword (current)
/// 2. RawPassword
/// 3. ClearPassword
/// 4. PasswordInput
#[derive(Debug, Clone)]
pub struct PlainPassword(String);

impl PlainPassword {
    pub fn new(password: impl Into<String>) -> Result<Self, ValueObjectError> {
        let password = password.into();
        
        if password.len() < 8 {
            return Err(ValueObjectError::InvalidPassword(
                "Password must be at least 8 characters".into()
            ));
        }
        
        if password.len() > 128 {
            return Err(ValueObjectError::InvalidPassword(
                "Password too long (max 128 characters)".into()
            ));
        }
        
        if !password.chars().any(|c| c.is_ascii_digit()) {
            return Err(ValueObjectError::InvalidPassword(
                "Password must contain at least one digit".into()
            ));
        }
        
        Ok(Self(password))
    }
    
    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl fmt::Display for PlainPassword {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "***PASSWORD***")
    }
}

/// Value Object Errors
#[derive(Debug, thiserror::Error)]
pub enum ValueObjectError {
    #[error("Invalid email: {0}")]
    InvalidEmail(String),
    
    #[error("Invalid password: {0}")]
    InvalidPassword(String),
}

impl serde::Serialize for ValueObjectError {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::ser::Serializer,
    {
        serializer.serialize_str(self.to_string().as_ref())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_valid_email() {
        let email = UserEmail::new("user@example.com").unwrap();
        assert_eq!(email.as_str(), "user@example.com");
    }
    
    #[test]
    fn test_invalid_email() {
        assert!(UserEmail::new("invalid").is_err());
        assert!(UserEmail::new("").is_err());
    }
    
    #[test]
    fn test_valid_password() {
        let password = PlainPassword::new("password123").unwrap();
        assert_eq!(password.as_str(), "password123");
    }
    
    #[test]
    fn test_invalid_password() {
        assert!(PlainPassword::new("pass123").is_err());
        assert!(PlainPassword::new("password").is_err());
    }
}
