//! API Routes
//!
//! Axum HTTP handlers for the identity module.
//!
//! Routes:
//! - POST /api/v1/identity/register
//! - GET /api/v1/identity/users/:id
//!
//! Alternative naming options:
//! 1. routes (current)
//! 2. handlers
//! 3. endpoints
//! 4. controller

use axum::{
    routing::post,
    Router,
    extract::{State, Json},
    http::StatusCode,
    response::IntoResponse,
};
use uuid::Uuid;

use super::dto::{RegisterUserRequest, RegisterUserResponse, ErrorResponse};
use super::state::IdentityState;
use identity_workflows::{commands::RegisterUserCommand, handlers::WorkflowError};

/// Create identity router
pub fn create_identity_router(state: IdentityState) -> Router {
    Router::new()
        .route("/api/v1/identity/register", post(register_user))
        .with_state(state)
}

/// Register User Handler
async fn register_user(
    State(state): State<IdentityState>,
    Json(payload): Json<RegisterUserRequest>,
) -> impl IntoResponse {
    tracing::info!("Received registration request for: {}", payload.email);
    
    // Create and validate command
    let command = match RegisterUserCommand::new(&payload.email, &payload.password) {
        Ok(cmd) => cmd,
        Err(e) => {
            tracing::warn!("Invalid command: {}", e);
            return (
                StatusCode::BAD_REQUEST,
                Json(ErrorResponse::new("validation_error", e.to_string())),
            );
        }
    };
    
    // Execute workflow
    match state.register_workflow.execute(command).await {
        Ok(user) => {
            tracing::info!("User registered successfully: {}", user.id);
            (
                StatusCode::CREATED,
                Json(RegisterUserResponse::success(
                    user.id,
                    user.email.to_string(),
                )),
            )
        }
        Err(e) => {
            tracing::error!("Registration failed: {}", e);
            
            let (status, error_response) = match &e {
                WorkflowError::DuplicateEmail(_) => (
                    StatusCode::CONFLICT,
                    ErrorResponse::new("duplicate_email", e.to_string()),
                ),
                WorkflowError::InvalidInput(_) => (
                    StatusCode::BAD_REQUEST,
                    ErrorResponse::new("invalid_input", e.to_string()),
                ),
                _ => (
                    StatusCode::INTERNAL_SERVER_ERROR,
                    ErrorResponse::new("internal_error", "Registration failed"),
                ),
            };
            
            (status, Json(error_response))
        }
    }
}
