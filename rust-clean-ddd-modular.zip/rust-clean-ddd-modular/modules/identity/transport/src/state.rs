//! Application State
//!
//! Shared state for Axum handlers.
//!
//! Alternative naming options:
//! 1. state (current)
//! 2. app_state
//! 3. shared_state
//! 4. context

use std::sync::Arc;
use deadpool::managed::Pool;
use identity_workflows::handlers::RegisterUserWorkflow;
use identity_adapters::{PostgresUserRepository, PostgresOutboxRepository, KanalEventBus};

/// Identity Module State
///
/// Alternative naming options:
/// 1. IdentityState (current)
/// 2. IdentityContext
/// 3. IdentityAppState
/// 4. IdentityModules
pub struct IdentityState {
    pub register_workflow: RegisterUserWorkflow,
}

impl IdentityState {
    pub fn new(
        pool: Pool<deadpool_postgres::Manager>,
        event_bus: KanalEventBus,
    ) -> Self {
        // Create stateless repositories
        let user_repo = Arc::new(PostgresUserRepository::new());
        let outbox_repo = Arc::new(PostgresOutboxRepository::new());
        
        // Create workflow with dependencies
        #[cfg(feature = "event-bus")]
        let register_workflow = RegisterUserWorkflow::new(
            pool,
            user_repo,
            outbox_repo,
            event_bus.sender(),
        );
        
        #[cfg(not(feature = "event-bus"))]
        let register_workflow = RegisterUserWorkflow::new(
            pool,
            user_repo,
            outbox_repo,
        );
        
        Self {
            register_workflow,
        }
    }
}
