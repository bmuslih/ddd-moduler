//! Email Worker (Event Receiver)
//!
//! Background worker that subscribes to domain events
//! and handles them (e.g., sending emails).
//!
//! Alternative naming options:
//! 1. email_worker (current)
//! 2. event_handler
//! 3. notification_worker
//! 4. event_consumer

use identity_adapters::{EventSubscriber, KanalEventBus};
use identity_domain::events::{DomainEvent, UserCreatedEvent};

/// Spawn email worker
pub async fn spawn_email_worker(subscriber: EventSubscriber) {
    tokio::spawn(async move {
        email_worker_loop(subscriber).await;
    });
}

/// Email worker main loop
async fn email_worker_loop(subscriber: EventSubscriber) {
    tracing::info!("EmailWorker: Started");
    
    loop {
        match subscriber.recv().await {
            Some(event) => {
                handle_event(event).await;
            }
            None => {
                tracing::warn!("EmailWorker: Channel closed, stopping");
                break;
            }
        }
    }
}

/// Handle domain event
async fn handle_event(event: Box<dyn DomainEvent>) {
    let event_type = event.event_type();
    
    tracing::debug!("EmailWorker: Received event: {}", event_type);
    
    match event_type {
        "user.created" => {
            handle_user_created(event.as_ref()).await;
        }
        _ => {
            tracing::warn!("EmailWorker: Unknown event type: {}", event_type);
        }
    }
}

/// Handle UserCreatedEvent
async fn handle_user_created(event: &dyn DomainEvent) {
    if let Some(user_event) = event.as_any().downcast_ref::<UserCreatedEvent>() {
        let email = user_event.email();
        let user_id = user_event.user_id();
        
        tracing::info!(
            "EmailWorker: Sending welcome email to {} (user_id: {})",
            email,
            user_id
        );
        
        send_welcome_email(email.as_str()).await;
        
        tracing::info!("EmailWorker: Welcome email sent to {}", email);
    }
}

/// Simulate sending welcome email
async fn send_welcome_email(email: &str) {
    tokio::time::sleep(tokio::time::Duration::from_millis(100)).await;
    tracing::debug!("[EMAIL SENT] Welcome email to: {}", email);
}
