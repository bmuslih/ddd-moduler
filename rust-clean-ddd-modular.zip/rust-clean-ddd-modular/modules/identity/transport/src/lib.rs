//! Identity Transport Layer (API Layer)
//!
//! Handles external HTTP requests and responses.
//! Contains: Axum routes, DTOs, Handlers.
//!
//! Layer alternative names:
//! 1. transport (current) ✅
//! 2. presentation
//! 3. api
//! 4. delivery

pub mod dto;
pub mod routes;
pub mod state;
pub mod email_worker;

pub use routes::create_identity_router;
pub use state::IdentityState;
