//! Data Transfer Objects
//!
//! DTOs for transferring data between API and workflows layers.
//!
//! DTOs:
//! - RegisterUserRequest
//! - RegisterUserResponse
//! - UserResponse
//! - ErrorResponse
//!
//! Alternative naming options:
//! 1. dto (current)
//! 2. requests
//! 3. payloads
//! 4. view_models

use serde::{Deserialize, Serialize};
use uuid::Uuid;

/// Register User Request DTO
///
/// Alternative naming options:
/// 1. RegisterUserRequest (current)
/// 2. CreateUserRequest
/// 3. SignUpRequest
/// 4. RegisterRequest
#[derive(Debug, Serialize, Deserialize)]
pub struct RegisterUserRequest {
    pub email: String,
    pub password: String,
}

/// Register User Response DTO
///
/// Alternative naming options:
/// 1. RegisterUserResponse (current)
/// 2. CreateUserResponse
/// 3. SignUpResponse
/// 4. RegistrationResult
#[derive(Debug, Serialize, Deserialize)]
pub struct RegisterUserResponse {
    pub user_id: String,
    pub email: String,
    pub message: String,
}

impl RegisterUserResponse {
    pub fn success(user_id: Uuid, email: String) -> Self {
        Self {
            user_id: user_id.to_string(),
            email,
            message: "User registered successfully".to_string(),
        }
    }
}

/// User Response DTO
#[derive(Debug, Serialize, Deserialize)]
pub struct UserResponse {
    pub id: String,
    pub email: String,
    pub created_at: String,
}

/// Error Response DTO
///
/// Alternative naming options:
/// 1. ErrorResponse (current)
/// 2. ApiError
/// 3. ErrorDto
/// 4. FailureResponse
#[derive(Debug, Serialize, Deserialize)]
pub struct ErrorResponse {
    pub error: String,
    pub message: String,
}

impl ErrorResponse {
    pub fn new(error: impl Into<String>, message: impl Into<String>) -> Self {
        Self {
            error: error.into(),
            message: message.into(),
        }
    }
}
