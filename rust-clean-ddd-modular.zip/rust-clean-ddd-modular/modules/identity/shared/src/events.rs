//! Shared Domain Events
//!
//! Domain events for identity module that can be shared/used
//! by multiple features.
//!
//! Events:
//! - UserCreatedEvent (from Registration)
//! - UserLoggedInEvent (from Login)
//!
//! Alternative naming options:
//! 1. events (current)
//! 2. domain_events
//! 3. notifications
//! 4. signals

use std::any::Any;
use chrono::{DateTime, Utc};
use uuid::Uuid;

use identity_domain::value_objects::UserEmail;

/// Domain Event trait (for shared kernel compatibility)
pub trait DomainEvent: Send + Sync + std::fmt::Debug + 'static {
    fn event_type(&self) -> &str;
    fn as_any(&self) -> &dyn Any;
    fn occurred_at(&self) -> DateTime<Utc>;
}

/// User Created Event
///
/// Raised when a new user registers.
/// Used by: Registration feature, Email worker
///
/// Alternative naming options:
/// 1. UserCreatedEvent (current)
/// 2. UserRegisteredEvent
/// 3. AccountCreatedEvent
/// 4. RegistrationEvent
#[derive(Debug, Clone)]
pub struct UserCreatedEvent {
    user_id: Uuid,
    email: UserEmail,
    occurred_at: DateTime<Utc>,
}

impl UserCreatedEvent {
    pub fn new(user_id: Uuid, email: UserEmail, occurred_at: DateTime<Utc>) -> Self {
        Self {
            user_id,
            email,
            occurred_at,
        }
    }
    
    pub fn user_id(&self) -> &Uuid {
        &self.user_id
    }
    
    pub fn email(&self) -> &UserEmail {
        &self.email
    }
}

impl DomainEvent for UserCreatedEvent {
    fn event_type(&self) -> &str {
        "identity.user.created"
    }
    
    fn as_any(&self) -> &dyn Any {
        self
    }
    
    fn occurred_at(&self) -> DateTime<Utc> {
        self.occurred_at
    }
}

/// User Logged In Event
///
/// Raised when a user successfully logs in.
/// Used by: Login feature, Security monitoring, Analytics
///
/// Alternative naming options:
/// 1. UserLoggedInEvent (current)
/// 2. UserAuthenticatedEvent
/// 3. LoginSuccessEvent
/// 4. AuthenticationEvent
#[derive(Debug, Clone)]
pub struct UserLoggedInEvent {
    user_id: Uuid,
    email: UserEmail,
    occurred_at: DateTime<Utc>,
    ip_address: Option<String>,
}

impl UserLoggedInEvent {
    pub fn new(
        user_id: Uuid,
        email: UserEmail,
        ip_address: Option<String>,
    ) -> Self {
        Self {
            user_id,
            email,
            occurred_at: Utc::now(),
            ip_address,
        }
    }
    
    pub fn user_id(&self) -> &Uuid {
        &self.user_id
    }
    
    pub fn email(&self) -> &UserEmail {
        &self.email
    }
    
    pub fn ip_address(&self) -> Option<&String> {
        self.ip_address.as_ref()
    }
}

impl DomainEvent for UserLoggedInEvent {
    fn event_type(&self) -> &str {
        "identity.user.logged_in"
    }
    
    fn as_any(&self) -> &dyn Any {
        self
    }
    
    fn occurred_at(&self) -> DateTime<Utc> {
        self.occurred_at
    }
}
