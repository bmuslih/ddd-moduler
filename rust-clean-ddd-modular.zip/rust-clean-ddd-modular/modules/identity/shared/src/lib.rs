//! Identity Module Shared Components
//!
//! Components shared between multiple features within the identity module.
//! For example: Registration and Login both use UserRepository.
//!
//! Shared components:
//! - UserRepository trait (used by Register, Login, GetUser, etc.)
//! - Common domain events
//! - Common value objects (if needed)
//!
//! This follows the DRY principle - don't repeat interfaces.

pub mod ports;
pub mod events;

pub use ports::{UserRepository, UserRepositoryError};
pub use events::{UserCreatedEvent, UserLoggedInEvent};
