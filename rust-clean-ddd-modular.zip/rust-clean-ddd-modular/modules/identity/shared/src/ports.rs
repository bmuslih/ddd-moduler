//! Shared Repository Ports
//!
//! Repository interfaces shared across multiple identity features.
//! Both Register and Login use these ports.
//!
//! Alternative naming options:
//! 1. ports (current)
//! 2. interfaces
//! 3. traits
//! 4. contracts

use async_trait::async_trait;
use tokio_postgres::GenericClient;
use uuid::Uuid;

use identity_domain::{User, UserId};

/// User Repository Port
///
/// SHARED by: Register, Login, GetUser, UpdateUser, etc.
/// This is the single source of truth for user persistence.
///
/// Alternative naming options:
/// 1. UserRepository (current)
/// 2. UserPersistence
/// 3. UserStore
/// 4. UserGateway
#[async_trait]
pub trait UserRepository: Send + Sync {
    /// Save a new user
    async fn save<C: GenericClient + Send + Sync>(
        &self,
        client: &C,
        user: &User,
    ) -> Result<(), UserRepositoryError>;
    
    /// Find user by ID
    async fn find_by_id<C: GenericClient + Send + Sync>(
        &self,
        client: &C,
        id: &UserId,
    ) -> Result<Option<User>, UserRepositoryError>;
    
    /// Find user by email (needed for Login & Register)
    async fn find_by_email<C: GenericClient + Send + Sync>(
        &self,
        client: &C,
        email: &str,
    ) -> Result<Option<User>, UserRepositoryError>;
    
    /// Check if email exists (needed for Register)
    async fn exists_by_email<C: GenericClient + Send + Sync>(
        &self,
        client: &C,
        email: &str,
    ) -> Result<bool, UserRepositoryError>;
    
    /// Update user (needed for Login - update last_login, etc.)
    async fn update<C: GenericClient + Send + Sync>(
        &self,
        client: &C,
        user: &User,
    ) -> Result<(), UserRepositoryError>;
}

/// User Repository Errors
#[derive(Debug, thiserror::Error)]
pub enum UserRepositoryError {
    #[error("Database error: {0}")]
    Database(String),
    
    #[error("Not found")]
    NotFound,
    
    #[error("Duplicate entry: {0}")]
    Duplicate(String),
}

impl From<tokio_postgres::Error> for UserRepositoryError {
    fn from(err: tokio_postgres::Error) -> Self {
        UserRepositoryError::Database(err.to_string())
    }
}

impl serde::Serialize for UserRepositoryError {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::ser::Serializer,
    {
        serializer.serialize_str(self.to_string().as_ref())
    }
}
