//! Event Bus Adapter (using kanal)
//!
//! High-performance event bus implementation using kanal channels.
//!
//! Alternative naming options:
//! 1. event_bus (current)
//! 2. message_bus
//! 3. event_adapter
//! 4. channel_bus

use std::any::Any;
use std::sync::Arc;
use kanal::{Sender, Receiver, unbounded_async};
use async_trait::async_trait;
use chrono::DateTime;

/// Domain Event trait (re-exported)
pub use identity_domain::events::DomainEvent;

/// Event Subscriber
#[derive(Clone)]
pub struct EventSubscriber {
    receiver: Arc<Receiver<Box<dyn DomainEvent>>>,
}

impl EventSubscriber {
    pub fn new(receiver: Receiver<Box<dyn DomainEvent>>) -> Self {
        Self {
            receiver: Arc::new(receiver),
        }
    }
    
    /// Receive the next event (async)
    pub async fn recv(&self) -> Option<Box<dyn DomainEvent>> {
        self.receiver.recv().await.ok()
    }
}

/// Kanal Event Bus
///
/// Alternative naming options:
/// 1. KanalEventBus (current)
/// 2. AsyncEventBus
/// 3. ChannelEventBus
/// 4. InMemoryEventBus
pub struct KanalEventBus {
    sender: Sender<Box<dyn DomainEvent>>,
}

impl KanalEventBus {
    pub fn new() -> Self {
        let (sender, _) = unbounded_async();
        Self { sender }
    }
    
    /// Get sender for publishing events
    pub fn sender(&self) -> Sender<Box<dyn DomainEvent>> {
        self.sender.clone()
    }
    
    /// Get subscriber for receiving events
    pub fn subscribe(&self) -> EventSubscriber {
        let (_, receiver) = unbounded_async();
        EventSubscriber::new(receiver)
    }
}

impl Default for KanalEventBus {
    fn default() -> Self {
        Self::new()
    }
}

/// Event Bus Errors
#[derive(Debug, thiserror::Error)]
pub enum EventBusError {
    #[error("Failed to send event: {0}")]
    SendError(String),
    
    #[error("Channel closed")]
    ChannelClosed,
}

impl From<kanal::SendError<Box<dyn DomainEvent>>> for EventBusError {
    fn from(err: kanal::SendError<Box<dyn DomainEvent>>) -> Self {
        EventBusError::SendError(err.to_string())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use identity_domain::events::UserCreatedEvent;
    use uuid::Uuid;
    
    #[tokio_test]
    async fn test_event_bus_publish_subscribe() {
        let bus = KanalEventBus::new();
        let subscriber = bus.subscribe();
        
        // Create and publish event
        let user_id = Uuid::new_v4();
        let email = identity_domain::UserEmail::new("test@example.com").unwrap();
        let event = UserCreatedEvent::new(user_id, email, chrono::Utc::now());
        
        bus.sender().send(Box::new(event)).await.unwrap();
        
        // Receive event
        let received = subscriber.recv().await;
        assert!(received.is_some());
    }
}
