//! Identity Adapters Layer (Infrastructure Layer)
//!
//! Implementations of the ports defined in workflows.
//! Handles database persistence and external system integration.
//!
//! Contains:
//! - PostgresUserRepository (production)
//! - PostgresOutboxRepository
//! - InMemoryUserRepository (testing)
//! - KanalEventBus
//!
//! Layer alternative names:
//! 1. adapters (current) ✅
//! 2. infrastructure
//! 3. gateways
//! 4. resources

pub mod repositories;
pub mod event_bus;

pub use repositories::{PostgresUserRepository, PostgresOutboxRepository, InMemoryUserRepository};
pub use event_bus::KanalEventBus;
