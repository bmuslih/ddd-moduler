//! Repository Implementations
//!
//! Concrete implementations of repository ports.
//! All repos are STATELESS - they accept GenericClient.
//!
//! Implementations:
//! 1. PostgresUserRepository - Production with prepare_cached
//! 2. PostgresOutboxRepository - Transactional outbox
//! 3. InMemoryUserRepository - Testing
//!
//! Alternative naming options:
//! 1. repositories (current)
//! 2. persistence
//! 3. storage
//! 4. data_access

use std::sync::Arc;
use std::collections::HashMap;
use async_trait::async_trait;
use tokio::sync::RwLock;
use tokio_postgres::{GenericClient, Row, Statement};
use chrono::{DateTime, Utc};
use uuid::Uuid;

use identity_shared::ports::{UserRepository, UserUserRepositoryError};
use identity_workflows::ports::{OutboxRepository, OutboxEvent};
use identity_domain::{User, UserId, UserEmail, HashedPassword, events::DomainEvent};

/// Postgres User Repository
///
/// STATELESS - Accepts GenericClient (Transaction or Connection).
/// Uses prepare_cached for performance optimization.
///
/// Alternative naming options:
/// 1. PostgresUserRepository (current)
/// 2. PostgreUserRepository
/// 3. DbUserRepository
/// 4. PersistentUserRepository
pub struct PostgresUserRepository {
    // Prepared statements cache (thread-safe)
    insert_stmt: Arc<tokio::sync::OnceLock<Statement>>,
    find_by_id_stmt: Arc<tokio::sync::OnceLock<Statement>>,
    find_by_email_stmt: Arc<tokio::sync::OnceLock<Statement>>,
    exists_by_email_stmt: Arc<tokio::sync::OnceLock<Statement>>,
}

impl PostgresUserRepository {
    pub fn new() -> Self {
        Self {
            insert_stmt: Arc::new(tokio::sync::OnceLock::new()),
            find_by_id_stmt: Arc::new(tokio::sync::OnceLock::new()),
            find_by_email_stmt: Arc::new(tokio::sync::OnceLock::new()),
            exists_by_email_stmt: Arc::new(tokio::sync::OnceLock::new()),
        }
    }
    
    /// Get or prepare insert statement (with cache)
    async fn get_insert_stmt<C: GenericClient + Send + Sync>(&self, client: &C) -> Result<&Statement, UserRepositoryError> {
        self.insert_stmt.get_or_try_init(|| async {
            client.prepare_cached(
                "INSERT INTO users (id, email, password_hash, created_at) VALUES ($1, $2, $3, $4)"
            ).await.map_err(UserRepositoryError::from)
        }).await.map_err(UserRepositoryError::from)
    }
    
    /// Get or prepare find_by_id statement (with cache)
    async fn get_find_by_id_stmt<C: GenericClient + Send + Sync>(&self, client: &C) -> Result<&Statement, UserRepositoryError> {
        self.find_by_id_stmt.get_or_try_init(|| async {
            client.prepare_cached(
                "SELECT id, email, password_hash, created_at FROM users WHERE id = $1"
            ).await.map_err(UserRepositoryError::from)
        }).await.map_err(UserRepositoryError::from)
    }
    
    /// Get or prepare find_by_email statement (with cache)
    async fn get_find_by_email_stmt<C: GenericClient + Send + Sync>(&self, client: &C) -> Result<&Statement, UserRepositoryError> {
        self.find_by_email_stmt.get_or_try_init(|| async {
            client.prepare_cached(
                "SELECT id, email, password_hash, created_at FROM users WHERE email = $1"
            ).await.map_err(UserRepositoryError::from)
        }).await.map_err(UserRepositoryError::from)
    }
    
    /// Get or prepare exists_by_email statement (with cache)
    async fn get_exists_by_email_stmt<C: GenericClient + Send + Sync>(&self, client: &C) -> Result<&Statement, UserRepositoryError> {
        self.exists_by_email_stmt.get_or_try_init(|| async {
            client.prepare_cached(
                "SELECT 1 FROM users WHERE email = $1"
            ).await.map_err(UserRepositoryError::from)
        }).await.map_err(UserRepositoryError::from)
    }
    
    fn row_to_user(&self, row: &Row) -> Result<User, UserRepositoryError> {
        let id: String = row.get(0)?;
        let email: String = row.get(1)?;
        let password_hash: String = row.get(2)?;
        let created_at: DateTime<Utc> = row.get(3)?;
        
        let id = Uuid::parse_str(&id)
            .map_err(|e| UserRepositoryError::Database(e.to_string()))?;
        
        let email = UserEmail::new(email)
            .map_err(|e| UserRepositoryError::Database(e.to_string()))?;
        
        let password_hash = HashedPassword::from_hash(password_hash);
        
        Ok(User::from_persistence(id, email, password_hash, created_at))
    }
}

impl Default for PostgresUserRepository {
    fn default() -> Self {
        Self::new()
    }
}

#[async_trait]
impl UserRepository for PostgresUserRepository {
    async fn save<C: GenericClient + Send + Sync>(&self, client: &C, user: &User) -> Result<(), UserRepositoryError> {
        let stmt = self.get_insert_stmt(client).await?;
        
        client.execute(
            stmt,
            &[
                &user.id.to_string(),
                &user.email.as_str(),
                &user.password_hash.as_str(),
                &user.created_at,
            ],
        ).await?;
        
        Ok(())
    }
    
    async fn find_by_id<C: GenericClient + Send + Sync>(&self, client: &C, id: &UserId) -> Result<Option<User>, UserRepositoryError> {
        let stmt = self.get_find_by_id_stmt(client).await?;
        
        let rows = client.query(stmt, &[&id.to_string()]).await?;
        
        if rows.is_empty() {
            return Ok(None);
        }
        
        let user = self.row_to_user(&rows[0])?;
        Ok(Some(user))
    }
    
    async fn find_by_email<C: GenericClient + Send + Sync>(&self, client: &C, email: &str) -> Result<Option<User>, UserRepositoryError> {
        let stmt = self.get_find_by_email_stmt(client).await?;
        
        let rows = client.query(stmt, &[&email]).await?;
        
        if rows.is_empty() {
            return Ok(None);
        }
        
        let user = self.row_to_user(&rows[0])?;
        Ok(Some(user))
    }
    
    async fn exists_by_email<C: GenericClient + Send + Sync>(&self, client: &C, email: &str) -> Result<bool, UserRepositoryError> {
        let stmt = self.get_exists_by_email_stmt(client).await?;
        
        let rows = client.query(stmt, &[&email]).await?;
        
        Ok(!rows.is_empty())
    }
    
    async fn update<C: GenericClient + Send + Sync>(&self, client: &C, user: &User) -> Result<(), UserRepositoryError> {
        // For now, just re-save the user (update if exists)
        // In production, you'd have a proper UPDATE statement
        self.save(client, user).await
    }
}

/// Postgres Outbox Repository
///
/// STATELESS - Accepts GenericClient (Transaction or Connection).
/// Implements transactional outbox pattern.
///
/// Alternative naming options:
/// 1. PostgresOutboxRepository (current)
/// 2. PostgresOutbox
/// 3. DbOutbox
/// 4. TransactionalOutbox
pub struct PostgresOutboxRepository {
    save_stmt: Arc<tokio::sync::OnceLock<Statement>>,
    get_unprocessed_stmt: Arc<tokio::sync::OnceLock<Statement>>,
    mark_processed_stmt: Arc<tokio::sync::OnceLock<Statement>>,
}

impl PostgresOutboxRepository {
    pub fn new() -> Self {
        Self {
            save_stmt: Arc::new(tokio::sync::OnceLock::new()),
            get_unprocessed_stmt: Arc::new(tokio::sync::OnceLock::new()),
            mark_processed_stmt: Arc::new(tokio::sync::OnceLock::new()),
        }
    }
    
    async fn get_save_stmt<C: GenericClient + Send + Sync>(&self, client: &C) -> Result<&Statement, UserRepositoryError> {
        self.save_stmt.get_or_try_init(|| async {
            client.prepare_cached(
                "INSERT INTO outbox_events (id, event_type, payload, created_at, processed) VALUES ($1, $2, $3, $4, $5)"
            ).await.map_err(UserRepositoryError::from)
        }).await.map_err(UserRepositoryError::from)
    }
    
    async fn get_unprocessed_stmt<C: GenericClient + Send + Sync>(&self, client: &C) -> Result<&Statement, UserRepositoryError> {
        self.get_unprocessed_stmt.get_or_try_init(|| async {
            client.prepare_cached(
                "SELECT id, event_type, payload, created_at, processed FROM outbox_events WHERE processed = false ORDER BY created_at"
            ).await.map_err(UserRepositoryError::from)
        }).await.map_err(UserRepositoryError::from)
    }
    
    async fn get_mark_processed_stmt<C: GenericClient + Send + Sync>(&self, client: &C) -> Result<&Statement, UserRepositoryError> {
        self.mark_processed_stmt.get_or_try_init(|| async {
            client.prepare_cached(
                "UPDATE outbox_events SET processed = true WHERE id = $1"
            ).await.map_err(UserRepositoryError::from)
        }).await.map_err(UserRepositoryError::from)
    }
}

impl Default for PostgresOutboxRepository {
    fn default() -> Self {
        Self::new()
    }
}

#[async_trait]
impl OutboxRepository for PostgresOutboxRepository {
    async fn save_event<C: GenericClient + Send + Sync>(&self, client: &C, event: &dyn DomainEvent) -> Result<(), UserRepositoryError> {
        let stmt = self.get_save_stmt(client).await?;
        
        let event_id = Uuid::new_v4();
        let payload = serde_json::to_string(event)
            .map_err(|e| UserRepositoryError::Serialization(e.to_string()))?;
        
        client.execute(
            stmt,
            &[
                &event_id.to_string(),
                &event.event_type(),
                &payload,
                &event.occurred_at(),
                &false,
            ],
        ).await?;
        
        tracing::debug!("Event saved to outbox: {} ({})", event.event_type(), event_id);
        
        Ok(())
    }
    
    async fn get_unprocessed_events<C: GenericClient + Send + Sync>(&self, client: &C) -> Result<Vec<OutboxEvent>, UserRepositoryError> {
        let stmt = self.get_unprocessed_stmt(client).await?;
        
        let rows = client.query(stmt, &[]).await?;
        
        let mut events = Vec::new();
        
        for row in rows {
            let id: String = row.get(0)?;
            let event_type: String = row.get(1)?;
            let payload: String = row.get(2)?;
            let created_at: DateTime<Utc> = row.get(3)?;
            let processed: bool = row.get(4)?;
            
            let id = Uuid::parse_str(&id)
                .map_err(|e| UserRepositoryError::Database(e.to_string()))?;
            
            events.push(OutboxEvent {
                id,
                event_type,
                payload,
                created_at,
                processed,
            });
        }
        
        Ok(events)
    }
    
    async fn mark_processed<C: GenericClient + Send + Sync>(&self, client: &C, event_ids: &[Uuid]) -> Result<(), UserRepositoryError> {
        let stmt = self.get_mark_processed_stmt(client).await?;
        
        for event_id in event_ids {
            client.execute(stmt, &[&event_id.to_string()]).await?;
        }
        
        Ok(())
    }
}

/// In-Memory User Repository (Testing)
///
/// Alternative naming options:
/// 1. InMemoryUserRepository (current)
/// 2. MockUserRepository
/// 3. TestUserRepository
/// 4. MemoryUserRepository
pub struct InMemoryUserRepository {
    users: Arc<RwLock<HashMap<UserId, User>>>,
    email_index: Arc<RwLock<HashMap<String, UserId>>>,
}

impl InMemoryUserRepository {
    pub fn new() -> Self {
        Self {
            users: Arc::new(RwLock::new(HashMap::new())),
            email_index: Arc::new(RwLock::new(HashMap::new())),
        }
    }
}

impl Default for InMemoryUserRepository {
    fn default() -> Self {
        Self::new()
    }
}

#[async_trait]
impl UserRepository for InMemoryUserRepository {
    async fn save<C: GenericClient + Send + Sync>(&self, _client: &C, user: &User) -> Result<(), UserRepositoryError> {
        let mut users = self.users.write().await;
        let mut email_index = self.email_index.write().await;
        
        let email_key = user.email.as_str().to_lowercase();
        if email_index.contains_key(&email_key) {
            return Err(UserRepositoryError::Duplicate(format!(
                "Email {} already exists",
                user.email
            )));
        }
        
        users.insert(user.id.clone(), user.clone());
        email_index.insert(email_key, user.id.clone());
        
        Ok(())
    }
    
    async fn find_by_id<C: GenericClient + Send + Sync>(&self, _client: &C, id: &UserId) -> Result<Option<User>, UserRepositoryError> {
        let users = self.users.read().await;
        Ok(users.get(id).cloned())
    }
    
    async fn find_by_email<C: GenericClient + Send + Sync>(&self, _client: &C, email: &str) -> Result<Option<User>, UserRepositoryError> {
        let email_index = self.email_index.read().await;
        let email_key = email.to_lowercase();
        
        if let Some(user_id) = email_index.get(&email_key) {
            let users = self.users.read().await;
            return Ok(users.get(user_id).cloned());
        }
        
        Ok(None)
    }
    
    async fn exists_by_email<C: GenericClient + Send + Sync>(&self, _client: &C, email: &str) -> Result<bool, UserRepositoryError> {
        let email_index = self.email_index.read().await;
        let email_key = email.to_lowercase();
        Ok(email_index.contains_key(&email_key))
    }
    
    async fn update<C: GenericClient + Send + Sync>(&self, _client: &C, user: &User) -> Result<(), UserRepositoryError> {
        let mut users = self.users.write().await;
        users.insert(user.id.clone(), user.clone());
        Ok(())
    }
}

// Note: InMemoryUserRepository tests require special handling
// because GenericClient is not implemented for ()
// See tests in integration tests instead
